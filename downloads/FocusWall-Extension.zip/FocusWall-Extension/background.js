// FocusWall - nền (service worker)

function updateBadge() {
  chrome.storage.local.get({ wallEnd: 0 }, ({ wallEnd }) => {
    const left = wallEnd - Date.now();
    if (left > 0) {
      chrome.action.setBadgeBackgroundColor({ color: "#6366f1" });
      chrome.action.setBadgeText({ text: Math.ceil(left / 60000) + "m" });
    } else {
      chrome.action.setBadgeText({ text: "" });
    }
  });
}

function scheduleWall(end) {
  chrome.alarms.create("wallEnd", { when: end });
  chrome.alarms.create("wallTick", { periodInMinutes: 0.5 });
  updateBadge();
}

chrome.runtime.onMessage.addListener((m, sender) => {
  if (m.type === "leave" && sender.tab) {
    // Thoát khỏi trang bị chặn: đóng tab (nếu là tab duy nhất thì chuyển về trang trắng)
    chrome.tabs.query({ windowId: sender.tab.windowId }, (tabs) => {
      if (tabs.length > 1) chrome.tabs.remove(sender.tab.id);
      else chrome.tabs.update(sender.tab.id, { url: "about:blank" });
    });
  }
  if (m.type === "wallStart") scheduleWall(m.end);
});

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "wallEnd") {
    chrome.storage.local.set({ wallEnd: 0 });
    chrome.alarms.clear("wallTick");
    chrome.action.setBadgeText({ text: "" });
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icon.png",
      title: "Hết giờ nhìn tường",
      message: "Quay lại học đi nhé!"
    });
  } else {
    updateBadge();
  }
});

// Khi trình duyệt mở lại: nếu đang đếm dở thì khôi phục huy hiệu và hẹn giờ
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get({ wallEnd: 0 }, ({ wallEnd }) => {
    if (wallEnd > Date.now()) scheduleWall(wallEnd);
    else chrome.storage.local.set({ wallEnd: 0 });
  });
});
