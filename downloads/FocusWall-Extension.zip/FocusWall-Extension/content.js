// FocusWall - chạy trên mỗi trang, chỉ hiện bảng khi trang nằm trong danh sách chặn
(async () => {
  if (!/^https?:$/.test(location.protocol)) return;
  const host = location.hostname.replace(/^www\./, "");
  const D = { shake: true, enabled: true, sites: [], todos: [], wallMin: 10, dark: true, font: 1, wallEnd: 0 };
  const S = await new Promise((r) => chrome.storage.local.get(D, r));
  if (!S.enabled || !S.sites.some((d) => host === d || host.endsWith("." + d))) return;

  const KEY = "focuswall_ok";
  if (sessionStorage.getItem(KEY) === "1" && !(S.wallEnd > Date.now())) return;

  chrome.storage.onChanged.addListener((c) => {
    for (const k in c) S[k] = c[k].newValue;
  });

  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  // ---- Giao diện (Shadow DOM để CSS của trang không ảnh hưởng) ----
  const hostEl = document.createElement("div");
  hostEl.style.cssText = "all:initial;position:fixed;inset:0;z-index:2147483647";
  hostEl.style.setProperty("--fs", S.font);
  const root = hostEl.attachShadow({ mode: "open" });
  root.innerHTML = `<style>
    #ov{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.55);
      backdrop-filter:blur(20px) saturate(1.2);-webkit-backdrop-filter:blur(20px) saturate(1.2);
      font-family:system-ui,"Segoe UI",Roboto,sans-serif;color:#fff;font-size:calc(18px*var(--fs));animation:ovin .9s}
    @keyframes ovin{from{opacity:0;backdrop-filter:blur(0);-webkit-backdrop-filter:blur(0)}}
    #card{width:min(580px,90vw);padding:34px 30px;text-align:center;border-radius:32px;
      background:linear-gradient(135deg,rgba(255,255,255,.26),rgba(255,255,255,.07));
      border:1px solid rgba(255,255,255,.45);box-shadow:0 24px 70px rgba(0,0,0,.45),inset 0 1px 0 rgba(255,255,255,.5);
      backdrop-filter:blur(26px);-webkit-backdrop-filter:blur(26px)}
    .pop{animation:pop .55s cubic-bezier(.2,.8,.3,1)}
    @keyframes pop{from{opacity:0;transform:scale(.9);filter:blur(8px)}}
    .fade{opacity:0;transform:translateY(12px);animation:fin .7s forwards}
    @keyframes fin{to{opacity:1;transform:none}}
    h1{font-size:1.55em;margin:0 0 20px}h2{font-size:1.15em;margin:0 0 14px}p{margin:10px 0}small{opacity:.8}
    ul{list-style:none;padding:0;margin:0 0 12px}li{margin:8px 0;padding:10px 14px;border-radius:14px;background:rgba(255,255,255,.14);text-align:left}
    .yn{display:flex;gap:12px;margin-top:22px}
    button{flex:1;font:inherit;font-weight:700;color:#fff;padding:14px;border-radius:20px;cursor:pointer;
      border:1px solid rgba(255,255,255,.5);background:linear-gradient(135deg,rgba(255,255,255,.3),rgba(255,255,255,.08));transition:transform .15s}
    button:hover{transform:scale(1.04)}
    .big{font-size:4em;font-weight:800;margin:14px 0;font-variant-numeric:tabular-nums}
    .shake{animation:shake .7s linear infinite}
    @keyframes shake{0%,100%{transform:none}12%{transform:translate(-2px,1px) rotate(-.2deg)}25%{transform:translate(2px,-1px) rotate(.15deg)}38%{transform:translate(-1px,-2px) rotate(.1deg)}52%{transform:translate(2px,2px) rotate(-.15deg)}66%{transform:translate(-2px,0) rotate(.2deg)}80%{transform:translate(1px,-2px) rotate(-.1deg)}}
    @media (prefers-reduced-motion:reduce){.shake{animation:none}}
  </style><div id="ov"><div id="card"></div></div>`;
  document.documentElement.appendChild(hostEl);
  const prevOverflow = document.documentElement.style.overflow;
  document.documentElement.style.overflow = "hidden";
  const quiet = setInterval(() => {
    document.querySelectorAll("video,audio").forEach((v) => { try { v.pause(); } catch (e) {} });
  }, 400);

  const $ = (id) => root.getElementById(id);
  const card = $("card");
  let d = 0;
  const t = (tx, tag = "p") => `<${tag} class="fade" style="animation-delay:${d++ * 90}ms">${tx}</${tag}>`;
  const YN = `<div class="yn"><button id="no">Không</button><button id="yes">Có</button></div>`;

  function show(html, bind) {
    d = 0;
    card.classList.remove("pop");
    void card.offsetWidth;
    card.classList.add("pop");
    card.innerHTML = html();
    if (bind) bind();
  }
  function close() {
    clearInterval(quiet);
    hostEl.remove();
    document.documentElement.style.overflow = prevOverflow;
  }
  function allow() {
    sessionStorage.setItem(KEY, "1");
    close();
  }
  function leave() {
    chrome.runtime.sendMessage({ type: "leave" });
  }

  // ---- Kịch bản ----
  function ask1() {
    show(() => t("Bạn có chắc bạn muốn vào không?", "h1") + YN, () => {
      $("no").onclick = leave;
      $("yes").onclick = () => (S.todos.length ? ask2() : free());
    });
  }
  function free() {
    show(() => t("Bạn không có việc gì nên có thể vào nhé", "h1"), () => setTimeout(allow, 2000));
  }
  function ask2() {
    if (!S.todos.length) return free();
    show(
      () =>
        t("Thật đấy à? Bạn còn những việc này chưa làm:", "h2") +
        "<ul>" + S.todos.slice(0, 8).map((x) => `<li class="fade" style="animation-delay:${d++ * 120}ms">${esc(x.text)}</li>`).join("") + "</ul>" +
        t("Bạn còn những việc này chưa làm, bạn đã chắc chắn tiếp tục không?") + YN,
      () => {
        $("no").onclick = leave;
        $("yes").onclick = () => {
          const end = Date.now() + S.wallMin * 60000;
          S.wallEnd = end;
          chrome.storage.local.set({ wallEnd: end });
          chrome.runtime.sendMessage({ type: "wallStart", end });
          wall(end);
        };
      }
    );
  }
  function wall(end) {
    show(
      () =>
        `<div class="${S.shake ? "shake" : ""}">` +
        t("Cho bạn suy nghĩ lại vì còn việc làm, hãy nhìn vào tường đi trong thời gian này:", "h2") +
        `<div id="cd" class="big fade" style="animation-delay:300ms">--:--</div>` +
        t("Thoát ra thì đồng hồ vẫn chạy ngầm đấy.", "small") +
        `</div>`,
      () => {
        const tick = () => {
          const l = Math.max(0, Math.ceil((end - Date.now()) / 1000));
          $("cd").textContent = String(Math.floor(l / 60)).padStart(2, "0") + ":" + String(l % 60).padStart(2, "0");
          if (l <= 0) { clearInterval(iv); ask2(); }
        };
        const iv = setInterval(tick, 250);
        tick();
      }
    );
  }

  if (S.wallEnd > Date.now()) wall(S.wallEnd);
  else ask1();
})();
