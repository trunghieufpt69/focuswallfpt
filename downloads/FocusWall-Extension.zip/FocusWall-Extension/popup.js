// FocusWall - cửa sổ popup
const $ = (s) => document.querySelector(s);
const PRESETS = [
  ["YouTube", "youtube.com"], ["TikTok", "tiktok.com"], ["Facebook", "facebook.com"],
  ["Instagram", "instagram.com"], ["X", "x.com"], ["Twitter", "twitter.com"],
  ["Reddit", "reddit.com"], ["Netflix", "netflix.com"], ["Discord", "discord.com"],
  ["Twitch", "twitch.tv"], ["Pinterest", "pinterest.com"]
];
const DEF = { shake: true, enabled: true, sites: [], todos: [], wallMin: 10, dark: true, font: 1, wallEnd: 0 };
let S = { ...DEF };
let page = "menu";
let tmp = null;   // dữ liệu tạm trong lúc chọn, chỉ lưu khi bấm "Áp dụng"
let timer = null;
let n = 0;        // đếm thứ tự để chữ hiện dần lần lượt

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const save = (o) => { Object.assign(S, o); return chrome.storage.local.set(o); };
const fmt = (t) => new Date(t).toLocaleString("vi-VN", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" });
const F = (txt, tag = "p") => `<${tag} class="fade" style="animation-delay:${n++ * 70}ms">${txt}</${tag}>`;
const BTN = (id, txt) => `<button class="glass btn fade" id="${id}" style="animation-delay:${n++ * 70}ms">${txt}</button>`;
const head = (t) => `<div class="head"><button id="back" class="back" title="Quay lại">←</button>${F(esc(t), "h2")}</div>`;
const domain = (v) => v.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").split("/")[0];
const go = (p) => { tmp = null; page = p; render(); };

function render() {
  clearInterval(timer);
  n = 0;
  document.body.classList.toggle("light", !S.dark);
  document.documentElement.style.setProperty("--fs", S.font);
  const m = $("#app");
  m.style.animation = "none"; void m.offsetWidth; m.style.animation = "";
  const [html, bind] = ({ menu, sites, time, settings, info, todo })[page]();
  m.innerHTML = html;
  const b = $("#back");
  if (b) b.onclick = () => go("menu");
  document.querySelectorAll("[id^=go-]").forEach((e) => (e.onclick = () => go(e.id.slice(3))));
  if (bind) bind();
}

// ---------- Menu ----------
function menu() {
  const left = S.wallEnd - Date.now();
  const html =
    F("FocusWall", "h1") + F("Kỳ thi không chờ ai. Tập trung đi.") +
    (left > 0 ? `<div class="glass fade" style="animation-delay:${n++ * 70}ms">Đang nhìn tường: <b id="wl">--:--</b></div>` : "") +
    `<label class="glass row fade" style="animation-delay:${n++ * 70}ms"><span>Bảo vệ: <b>${S.enabled ? "ĐANG BẬT" : "đang tắt"}</b></span><input type="checkbox" id="en" ${S.enabled ? "checked" : ""}></label>` +
    BTN("go-sites", `Lựa chọn trang web cần chặn (${S.sites.length})`) +
    BTN("go-time", `Thời gian nhìn tường: ${S.wallMin} phút`) +
    BTN("go-todo", `Việc cần làm (${S.todos.length})`) +
    BTN("go-settings", "Cài đặt") +
    BTN("go-info", "Thông tin app");
  return [html, () => {
    $("#en").onchange = (e) => save({ enabled: e.target.checked }).then(render);
    if (left > 0) {
      const tick = () => {
        const l = Math.max(0, Math.ceil((S.wallEnd - Date.now()) / 1000));
        const el = $("#wl");
        if (el) el.textContent = String(Math.floor(l / 60)).padStart(2, "0") + ":" + String(l % 60).padStart(2, "0");
      };
      tick();
      timer = setInterval(tick, 500);
    }
  }];
}

// ---------- Chọn trang web ----------
function sites() {
  tmp = tmp || new Set(S.sites);
  const custom = [...tmp].filter((d) => !PRESETS.some((p) => p[1] === d));
  const row = (label, d) =>
    `<label class="glass row"><span>${esc(label)}</span><input type="checkbox" data-d="${esc(d)}" ${tmp.has(d) ? "checked" : ""}></label>`;
  const html =
    head("Chọn trang web cần chặn") +
    `<div class="chips fade" style="animation-delay:${n++ * 70}ms"><button id="pre">Chọn giải trí</button><button id="clr">Bỏ hết</button></div>` +
    `<div class="list">${PRESETS.map((p) => row(p[0], p[1])).join("")}${custom.map((d) => row(d, d)).join("")}</div>` +
    `<div class="row"><input id="cs" class="inp" placeholder="Thêm trang khác, vd: example.com"><button id="add" class="glass" style="padding:10px 14px">Thêm</button></div>` +
    BTN("apply", "Áp dụng");
  return [html, () => {
    document.querySelectorAll("input[data-d]").forEach((c) => (c.onchange = () => (c.checked ? tmp.add(c.dataset.d) : tmp.delete(c.dataset.d))));
    $("#pre").onclick = () => { PRESETS.forEach((p) => tmp.add(p[1])); render(); };
    $("#clr").onclick = () => { tmp.clear(); render(); };
    const add = () => { const d = domain($("#cs").value); if (d.includes(".")) { tmp.add(d); render(); } };
    $("#add").onclick = add;
    $("#cs").onkeydown = (e) => { if (e.key === "Enter") add(); };
    $("#apply").onclick = () => save({ sites: [...tmp] }).then(() => go("menu"));
  }];
}

// ---------- Thời gian nhìn tường ----------
function time() {
  tmp = tmp ?? S.wallMin;
  const html =
    head("Thời gian nhìn tường") + F("Mỗi lần bạn cố vào mà còn việc chưa làm, bạn sẽ phải nhìn tường bao lâu?") +
    [1, 3, 5, 10, 15, 20, 30].map((m) => BTN("m" + m, (m === tmp ? "✓  " : "") + m + " phút" + (m === 10 ? " (mặc định)" : ""))).join("") +
    BTN("apply", "Áp dụng");
  return [html, () => {
    [1, 3, 5, 10, 15, 20, 30].forEach((m) => ($("#m" + m).onclick = () => { tmp = m; render(); }));
    $("#apply").onclick = () => save({ wallMin: tmp }).then(() => go("menu"));
  }];
}

// ---------- Cài đặt ----------
function settings() {
  const html =
    head("Cài đặt") +
    `<label class="glass row fade" style="animation-delay:${n++ * 70}ms"><span>${S.dark ? "Nền tối (chữ sáng)" : "Nền sáng (chữ tối)"}</span><input type="checkbox" id="dk" ${S.dark ? "checked" : ""}></label>` +
    `<label class="glass row fade" style="animation-delay:${n++ * 70}ms"><span>Rung nhẹ màn hình khi nhìn tường</span><input type="checkbox" id="sk" ${S.shake ? "checked" : ""}></label>` +
    `<div class="glass fade" style="animation-delay:${n++ * 70}ms"><div>Cỡ chữ</div><input type="range" id="fs" min="0.8" max="1.4" step="0.1" value="${S.font}" style="width:100%"><p>Chữ mẫu: Học đi, đừng lướt nữa!</p></div>`;
  return [html, () => {
    $("#dk").onchange = (e) => save({ dark: e.target.checked }).then(render);
    $("#sk").onchange = (e) => save({ shake: e.target.checked }).then(render);
    $("#fs").onchange = (e) => save({ font: +e.target.value }).then(render);
  }];
}

// ---------- Thông tin ----------
function info() {
  return [
    head("Thông tin app") + `<div class="glass fade" style="animation-delay:${n++ * 70}ms"><b>FocusWall 1.0</b><p>Khi bạn mở một trang bị chặn, FocusWall hỏi lại bạn, nhắc các việc chưa làm, và bắt bạn nhìn tường nếu bạn vẫn cố vào.</p><p>Mọi dữ liệu chỉ nằm trong trình duyệt của bạn, không gửi đi đâu cả.</p></div>`,
    null
  ];
}

// ---------- Việc cần làm ----------
function todo() {
  tmp = tmp || S.todos.map((t) => ({ ...t }));
  const item = (t, cls = "") =>
    `<div class="glass item ${cls}" data-id="${t.id}"><small>${fmt(t.time)}</small><div class="row"><span>${esc(t.text)}</span><button class="done" data-id="${t.id}">Xong</button></div></div>`;
  const html =
    head("Việc cần làm") +
    `<div class="list" id="list">${tmp.map((t) => item(t)).join("")}</div>` +
    `<div id="addrow" class="glass hidden"><input id="ti" class="inp" placeholder="Việc cần làm..."><div class="two"><button id="no">Thôi</button><button id="ok">OK</button></div></div>` +
    `<div class="bottom"><button id="plus" class="glass plus" title="Thêm việc">+</button><button id="apply" class="glass btn">Áp dụng</button></div>`;
  return [html, () => {
    const list = $("#list");
    const bindDone = (el) => (el.querySelector(".done").onclick = () => {
      tmp = tmp.filter((t) => String(t.id) !== el.dataset.id);
      el.remove();
    });
    list.querySelectorAll(".item").forEach(bindDone);
    $("#plus").onclick = () => { $("#addrow").classList.remove("hidden"); $("#ti").focus(); };
    $("#no").onclick = () => { $("#addrow").classList.add("hidden"); $("#ti").value = ""; };
    const ok = () => {
      const text = $("#ti").value.trim();
      if (!text) return;
      const now = Date.now();
      const t = { id: now, text, time: now };
      tmp.push(t);   // thêm xuống cuối danh sách
      list.insertAdjacentHTML("beforeend", item(t, "drop"));
      bindDone(list.lastElementChild);
      list.lastElementChild.scrollIntoView({ behavior: "smooth", block: "nearest" });
      $("#ti").value = "";
      $("#addrow").classList.add("hidden");
    };
    $("#ok").onclick = ok;
    $("#ti").onkeydown = (e) => { if (e.key === "Enter") ok(); };
    $("#apply").onclick = () => save({ todos: tmp }).then(() => go("menu"));
  }];
}

chrome.storage.local.get(DEF, (v) => { S = v; render(); });
